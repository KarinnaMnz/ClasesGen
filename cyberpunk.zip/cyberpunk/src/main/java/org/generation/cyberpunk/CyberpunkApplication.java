package org.generation.cyberpunk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CyberpunkApplication {

	public static void main(String[] args) {
		SpringApplication.run(CyberpunkApplication.class, args);
	}

}
