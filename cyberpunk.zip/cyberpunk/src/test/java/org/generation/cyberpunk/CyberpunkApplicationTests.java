package org.generation.cyberpunk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CyberpunkApplicationTests {

	@Test
	void contextLoads() {
	}

}
